<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'ogrenci_takip';

// 3306 portunu elle yazmaya gerek yok, çünkü varsayılan porttur
$conn = new mysqli($host, $user, $password, $database);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantı hatası: " . $conn->connect_error);
}
?>
