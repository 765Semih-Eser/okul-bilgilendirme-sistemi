<?php
session_start();
include "ayarlar/veritabani.php";

if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
 
    $kullanici_adi = $_POST["kullanici_adi"];
    $sifre = $_POST["sifre"];

    $sql = "SELECT * FROM kullanicilar WHERE kullanici_adi = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $kullanici_adi);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if ($sifre == $row["sifre"]) { // ileride hash yapılabilir
            $_SESSION["kullanici_id"] = $row["id"];
            $_SESSION["rol"] = $row["rol"];

            if ($row["rol"] == "admin") {
                header("Location: admin/panel.php");
            } else {
                header("Location: ogrenci/panel.php");
            }
            exit;
        } else {
            $hata = "Şifre yanlış!";
        }
    } else {
        $hata = "Kullanıcı bulunamadı!";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Giriş Yap</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f0f2f5;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .login-container {
      background-color: white;
      padding: 30px 40px;
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      width: 350px;
      text-align: center;
    }

    .login-container h2 {
      margin-bottom: 20px;
      color: #333;
    }

    .login-container input[type="text"],
    .login-container input[type="password"] {
      width: 100%;
      padding: 12px 15px;
      margin: 8px 0 20px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    .login-container input[type="submit"] {
      width: 100%;
      padding: 12px;
      background-color: #3b82f6;
      border: none;
      border-radius: 6px;
      color: white;
      font-weight: bold;
      cursor: pointer;
      font-size: 15px;
    }

    .login-container input[type="submit"]:hover {
      background-color: #2563eb;
    }

    .error-message {
      color: red;
      margin-bottom: 10px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Giriş Yap</h2>
    <?php if (!empty($hata)) echo "<p class='error-message'>⚠️ $hata</p>"; ?>
    <form method="post">
      <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
      <input type="password" name="sifre" placeholder="Şifre" required>
      <input type="submit" value="Giriş Yap">
    </form>
  </div>
</body>
</html>
