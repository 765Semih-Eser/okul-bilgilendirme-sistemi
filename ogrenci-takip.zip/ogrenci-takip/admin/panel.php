<?php
session_start();
if (!isset($_SESSION["kullanici_id"]) || $_SESSION["rol"] !== "admin") {
    header("Location: ../giris.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Yönetim Paneli</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .panel-container {
            max-width: 600px;
            margin: 60px auto;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            text-align: center;
        }

        h2 {
            color: #2c3e50;
            margin-bottom: 10px;
        }

        p {
            color: #555;
            margin-bottom: 30px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            margin: 15px 0;
        }

        ul li a {
            display: inline-block;
            padding: 12px 25px;
            background-color: #3b82f6;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.2s;
        }

        ul li a:hover {
            background-color: #2563eb;
        }

        .logout {
            background-color: #ef4444 !important;
        }

        .logout:hover {
            background-color: #dc2626 !important;
        }
    </style>
</head>
<body>
    <div class="panel-container">
        <h2>🎓 Yönetim Paneli</h2>
        <p><strong>Giriş yapan:</strong> <?php echo htmlspecialchars($_SESSION["rol"]); ?></p>

        <ul>
            <li><a href="ogrenci-yonetimi.php">📚 Öğrenci Yönetimi</a></li>
            <li><a href="ders-yonetimi.php">📖 Ders Yönetimi</a></li>
            <li><a href="not-girisi.php">📝 Not ve Devamsızlık Girişi</a></li>
            <li><a href="../cikis.php" class="logout">🚪 Çıkış Yap</a></li>
        </ul>
    </div>
</body>
</html>

