<?php
session_start();
if (!isset($_SESSION["kullanici_id"]) || $_SESSION["rol"] !== "admin") {
    header("Location: ../giris.php");
    exit;
}

include "../ayarlar/veritabani.php";

// Ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $ders_adi = $_POST["ders_adi"];

    $stmt = $conn->prepare("INSERT INTO dersler (ders_adi) VALUES (?)");
    $stmt->bind_param("s", $ders_adi);
    $stmt->execute();

    header("Location: ders-yonetimi.php");
    exit;
}

// Silme işlemi
if (isset($_GET["sil"])) {
    $id = intval($_GET["sil"]);

    $stmt = $conn->prepare("DELETE FROM dersler WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: ders-yonetimi.php");
    exit;
}

// Dersleri listele
$dersler = $conn->query("SELECT * FROM dersler ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ders Yönetimi</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 700px;
            margin: 50px auto;
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        }

        h2 {
            margin-top: 0;
            color: #2c3e50;
        }

        form {
            margin-bottom: 40px;
        }

        label {
            display: block;
            margin: 15px 0 6px;
            font-weight: bold;
            color: #444;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 12px;
            background-color: #3b82f6;
            border: none;
            color: white;
            border-radius: 6px;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #2563eb;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #e2e8f0;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f0f4f8;
        }

        tr:nth-child(even) {
            background-color: #f9fafb;
        }

        a.delete-link {
            color: #ef4444;
            font-weight: bold;
            text-decoration: none;
        }

        a.delete-link:hover {
            text-decoration: underline;
        }

        a.back-link {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            background-color: #6b7280;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
        }

        a.back-link:hover {
            background-color: #4b5563;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>📖 Ders Ekle</h2>
        <form method="post">
            <label>Ders Adı:</label>
            <input type="text" name="ders_adi" required>
            <input type="submit" value="Ekle">
        </form>

        <h2>📚 Mevcut Dersler</h2>
        <table>
            <tr>
                <th>#</th>
                <th>Ders Adı</th>
                <th>İşlem</th>
            </tr>
            <?php $i = 1; while ($row = $dersler->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= htmlspecialchars($row["ders_adi"]) ?></td>
                    <td>
                        <a class="delete-link" href="?sil=<?= $row["id"] ?>" onclick="return confirm('Bu dersi silmek istediğinize emin misiniz?')">Sil</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <a class="back-link" href="panel.php">⬅ Geri Dön</a>
    </div>
</body>
</html>
