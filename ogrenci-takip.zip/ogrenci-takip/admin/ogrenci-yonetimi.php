<?php
session_start();
if (!isset($_SESSION["kullanici_id"]) || $_SESSION["rol"] !== "admin") {
    header("Location: ../giris.php");
    exit;
}
include "../ayarlar/veritabani.php";

// Ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $kullanici_adi = $_POST["kullanici_adi"];
    $sifre = $_POST["sifre"];
    $ad_soyad = $_POST["ad_soyad"];
    $ogrenci_no = $_POST["ogrenci_no"];

     // ÖNCE kontrol et: Bu öğrenci no zaten var mı?
    $kontrol = $conn->prepare("SELECT id FROM ogrenciler WHERE ogrenci_no = ?");
    $kontrol->bind_param("s", $ogrenci_no);
    $kontrol->execute();
    $sonuc = $kontrol->get_result();

    if ($sonuc->num_rows > 0) {
        echo "<p style='color:red;'>⚠️ Bu öğrenci numarası zaten kayıtlı!</p>";
    } else {

    // Önce kullanıcılar tablosuna ekle
    $sql1 = "INSERT INTO kullanicilar (kullanici_adi, sifre, rol) VALUES (?, ?, 'ogrenci')";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("ss", $kullanici_adi, $sifre);
    $stmt1->execute();
    $kullanici_id = $stmt1->insert_id;

    // Sonra öğrenciler tablosuna ekle
    $sql2 = "INSERT INTO ogrenciler (kullanici_id, ad_soyad, ogrenci_no) VALUES (?, ?, ?)";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param("iss", $kullanici_id, $ad_soyad, $ogrenci_no);
    $stmt2->execute();

    header("Location: ogrenci-yonetimi.php");
    exit;
}
}
// Silme işlemi
if (isset($_GET["sil"])) {
    $ogrenci_id = intval($_GET["sil"]);

    // önce öğrenci kaydını al
    $stmtGet = $conn->prepare("SELECT kullanici_id FROM ogrenciler WHERE id = ?");
    $stmtGet->bind_param("i", $ogrenci_id);
    $stmtGet->execute();
    $result = $stmtGet->get_result();
    $ogrenci = $result->fetch_assoc();

    if ($ogrenci) {
        $kullanici_id = $ogrenci["kullanici_id"];

        // öğrenci tablosundan sil
        $stmtDelOgrenci = $conn->prepare("DELETE FROM ogrenciler WHERE id = ?");
        $stmtDelOgrenci->bind_param("i", $ogrenci_id);
        $stmtDelOgrenci->execute();

        // kullanıcılar tablosundan da sil
        $stmtDelKullanici = $conn->prepare("DELETE FROM kullanicilar WHERE id = ?");
        $stmtDelKullanici->bind_param("i", $kullanici_id);
        $stmtDelKullanici->execute();
    }

    header("Location: ogrenci-yonetimi.php");
    exit;
}

// Öğrencileri listele
$ogrenciler = $conn->query("SELECT ogrenciler.id, ad_soyad, ogrenci_no, kullanici_adi FROM ogrenciler INNER JOIN kullanicilar ON ogrenciler.kullanici_id = kullanicilar.id");
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Öğrenci Yönetimi</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f3f4f6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        form {
            margin-bottom: 40px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-top: 15px;
            color: #444;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: #3b82f6;
            border: none;
            color: white;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #2563eb;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        th, td {
            border: 1px solid #e2e8f0;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f0f4f8;
        }

        tr:nth-child(even) {
            background-color: #f9fafb;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            background-color: #6b7280;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
        }

        .back-link:hover {
            background-color: #4b5563;
        }

        .delete-link {
            color: #ef4444;
            font-weight: bold;
            text-decoration: none;
        }

        .delete-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>👩‍🎓 Öğrenci Ekle</h2>
        <form method="post">
            <label>Ad Soyad:</label>
            <input type="text" name="ad_soyad" required>

            <label>Öğrenci No:</label>
            <input type="text" name="ogrenci_no" required>

            <label>Kullanıcı Adı:</label>
            <input type="text" name="kullanici_adi" required>

            <label>Şifre:</label>
            <input type="password" name="sifre" required>

            <input type="submit" value="Ekle">
        </form>

        <h2>📋 Öğrenci Listesi</h2>
        <table>
            <tr>
                <th>#</th>
                <th>Ad Soyad</th>
                <th>Öğrenci No</th>
                <th>Kullanıcı Adı</th>
                <th>İşlem</th>
            </tr>

            <?php $i = 1; while ($row = $ogrenciler->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= htmlspecialchars($row["ad_soyad"]) ?></td>
                    <td><?= htmlspecialchars($row["ogrenci_no"]) ?></td>
                    <td><?= htmlspecialchars($row["kullanici_adi"]) ?></td>
                    <td><a class="delete-link" href="?sil=<?= $row["id"] ?>" onclick="return confirm('Silmek istediğinize emin misiniz?')">Sil</a></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <a class="back-link" href="panel.php">⬅ Geri Dön</a>
    </div>
</body>
</html>
