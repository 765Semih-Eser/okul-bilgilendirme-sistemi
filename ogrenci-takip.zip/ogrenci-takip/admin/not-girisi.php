<?php
session_start();
if (!isset($_SESSION["kullanici_id"]) || $_SESSION["rol"] !== "admin") {
    header("Location: ../giris.php");
    exit;
}
include "../ayarlar/veritabani.php";

// Ders listesini çek
$dersler = $conn->query("SELECT id, ders_adi FROM dersler ORDER BY ders_adi ASC");

// Not giriş işlemi
$mesaj = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $ogrenci_id  = $_POST["ogrenci_id"]  ?? null;                 // hidden
    $ders_id     = isset($_POST["ders_id"]) ? intval($_POST["ders_id"]) : null;
    $vize        = isset($_POST["vize"]) ? floatval($_POST["vize"]) : null;
    $final       = isset($_POST["final"]) ? floatval($_POST["final"]) : null;
    $devamsizlik = isset($_POST["devamsizlik"]) ? intval($_POST["devamsizlik"]) : null;

    // Basit doğrulama
    if (empty($ogrenci_id)) {
        $mesaj = "⚠️ Lütfen geçerli bir öğrenci numarası girin.";
    } elseif (empty($ders_id)) {
        $mesaj = "⚠️ Lütfen bir ders seçin.";
    } else {
        // Var mı kontrolü
        $kontrol = $conn->prepare("SELECT id FROM notlar WHERE ogrenci_id = ? AND ders_id = ?");
        $kontrol->bind_param("ii", $ogrenci_id, $ders_id);
        $kontrol->execute();
        $sonuc = $kontrol->get_result();

        if ($row = $sonuc->fetch_assoc()) {
            $stmt = $conn->prepare("UPDATE notlar SET vize_notu = ?, final_notu = ?, devamsizlik = ? WHERE id = ?");
            $stmt->bind_param("ddii", $vize, $final, $devamsizlik, $row["id"]);
        } else {
            $stmt = $conn->prepare("INSERT INTO notlar (ogrenci_id, ders_id, vize_notu, final_notu, devamsizlik) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiddi", $ogrenci_id, $ders_id, $vize, $final, $devamsizlik);
        }
        $stmt->execute();
        $mesaj = "✅ Not başarıyla kaydedildi.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Not Girişi</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background:#f4f6f8; margin:0; padding:0; }
        .container { max-width: 600px; margin: 50px auto; background:#fff; padding:40px; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.08); }
        h2 { margin-top:0; color:#2c3e50; }
        label { display:block; margin:15px 0 6px; font-weight:bold; color:#444; }
        input[type="text"], input[type="number"], select { width:100%; padding:12px; border:1px solid #ccc; border-radius:6px; font-size:14px; }
        input[type="submit"] { margin-top:25px; padding:12px; width:100%; background:#3b82f6; border:none; border-radius:6px; color:#fff; font-weight:bold; font-size:16px; cursor:pointer; }
        input[type="submit"]:hover { background:#2563eb; }
        .msg { font-weight:bold; margin-bottom:20px; }
        .ok { color: green; }
        .err { color: #ef4444; }
        .student-result { margin:10px 0; font-weight:bold; color:#2563eb; min-height:18px; }
        a.back-link { display:inline-block; margin-top:30px; text-decoration:none; background:#6b7280; color:#fff; padding:10px 20px; border-radius:6px; }
        a.back-link:hover { background:#4b5563; }
    </style>
    <script>
        function ogrenciGetir() {
            const ogrenciNo = document.getElementById("ogrenci_no").value;
            const sonucDiv  = document.getElementById("ogrenci_bilgisi");
            const hiddenId  = document.getElementById("ogrenci_id");

            if (ogrenciNo.trim() === "") {
                sonucDiv.textContent = "";
                hiddenId.value = "";
                return;
            }
            fetch("ogrenci-ara.php?ogrenci_no=" + encodeURIComponent(ogrenciNo))
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        hiddenId.value = data.id;
                        sonucDiv.textContent = "👤 " + data.ad_soyad;
                        sonucDiv.style.color = "#2563eb";
                    } else {
                        hiddenId.value = "";
                        sonucDiv.textContent = "❌ Öğrenci bulunamadı.";
                        sonucDiv.style.color = "#ef4444";
                    }
                })
                .catch(() => {
                    hiddenId.value = "";
                    sonucDiv.textContent = "❌ Arama sırasında bir hata oluştu.";
                    sonucDiv.style.color = "#ef4444";
                });
        }
    </script>
</head>
<body>
<div class="container">
    <h2>📝 Not ve Devamsızlık Girişi</h2>

    <?php if (!empty($mesaj)): ?>
        <p class="msg <?= str_starts_with($mesaj, '✅') ? 'ok' : 'err' ?>"><?= htmlspecialchars($mesaj) ?></p>
    <?php endif; ?>

    <!-- DİKKAT: Ders Seç alanı artık FORM İÇİNDE -->
    <form method="post">
        <label>Ders Seç:</label>
        <select name="ders_id" required>
            <option value="">-- Ders Seçin --</option>
            <?php if ($dersler) { while ($d = $dersler->fetch_assoc()): ?>
                <option value="<?= $d["id"] ?>"><?= htmlspecialchars($d["ders_adi"]) ?></option>
            <?php endwhile; } ?>
        </select>

        <label>Öğrenci Numarası Gir:</label>
        <input type="text" name="ogrenci_no" id="ogrenci_no" oninput="ogrenciGetir()" required>
        <input type="hidden" name="ogrenci_id" id="ogrenci_id">
        <div id="ogrenci_bilgisi" class="student-result"></div>

        <label>Vize Notu:</label>
        <input type="number" name="vize" min="0" max="100" step="0.01" required>

        <label>Final Notu:</label>
        <input type="number" name="final" min="0" max="100" step="0.01" required>

        <label>Devamsızlık (gün):</label>
        <input type="number" name="devamsizlik" min="0" max="100" required>

        <input type="submit" value="Kaydet">
    </form>

    <a class="back-link" href="panel.php">⬅ Geri Dön</a>
</div>
</body>
</html>
