<?php
include "../ayarlar/veritabani.php";

if (isset($_GET["ogrenci_no"])) {
    $ogrenci_no = $_GET["ogrenci_no"];

    $stmt = $conn->prepare("SELECT id, ad_soyad FROM ogrenciler WHERE ogrenci_no = ?");
    $stmt->bind_param("s", $ogrenci_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            "success" => true,
            "id" => $row["id"],
            "ad_soyad" => $row["ad_soyad"]
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Öğrenci bulunamadı."]);
    }
}
