<?php
header("Location: giris.php");
exit;
