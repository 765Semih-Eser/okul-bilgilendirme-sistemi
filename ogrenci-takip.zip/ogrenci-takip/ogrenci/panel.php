<?php
session_start();
if (!isset($_SESSION["kullanici_id"]) || $_SESSION["rol"] !== "ogrenci") {
    header("Location: ../giris.php");
    exit;
}

include "../ayarlar/veritabani.php";

// Öğrencinin kendi ID'sini bul
$kullanici_id = $_SESSION["kullanici_id"];

// ogrenciler tablosundan id'yi al
$stmt = $conn->prepare("SELECT id, ad_soyad FROM ogrenciler WHERE kullanici_id = ?");
$stmt->bind_param("i", $kullanici_id);
$stmt->execute();
$result = $stmt->get_result();
$ogrenci = $result->fetch_assoc();

if (!$ogrenci) {
    echo "Öğrenci bilgisi bulunamadı.";
    exit;
}

$ogrenci_id = $ogrenci["id"];
$ad_soyad = $ogrenci["ad_soyad"];

// notlar + dersler
$sql = "SELECT d.ders_adi, n.vize_notu, n.final_notu, n.devamsizlik, n.ortalama
        FROM notlar n
        INNER JOIN dersler d ON n.ders_id = d.id
        WHERE n.ogrenci_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $ogrenci_id);
$stmt->execute();
$notlar = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Öğrenci Paneli</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .panel-container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        }

        h2 {
            color: #2c3e50;
            margin-top: 0;
        }

        h3 {
            color: #3b82f6;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        table, th, td {
            border: 1px solid #e2e8f0;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f0f4f8;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9fafb;
        }

        .no-data {
            color: #ff4444;
            font-weight: bold;
        }

        a.logout {
            display: inline-block;
            background-color: #ef4444;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.2s;
        }

        a.logout:hover {
            background-color: #dc2626;
        }
    </style>
</head>
<body>
    <div class="panel-container">
        <h2>📋 Merhaba, <?= htmlspecialchars($ad_soyad) ?>!</h2>
        <h3>📝 Not ve Devamsızlık Bilgilerin</h3>

        <?php if ($notlar->num_rows === 0): ?>
            <p class="no-data">Henüz not bilginiz yok.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Ders</th>
                    <th>Vize</th>
                    <th>Final</th>
                    <th>Ortalama</th>
                    <th>Devamsızlık</th>
                </tr>
                <?php while ($n = $notlar->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($n["ders_adi"]) ?></td>
                        <td><?= $n["vize_notu"] ?></td>
                        <td><?= $n["final_notu"] ?></td>
                        <td><?= number_format($n["ortalama"], 2) ?></td>
                        <td><?= $n["devamsizlik"] ?> gün</td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php endif; ?>

        <a class="logout" href="../cikis.php">🚪 Çıkış Yap</a>
    </div>
</body>
</html>

